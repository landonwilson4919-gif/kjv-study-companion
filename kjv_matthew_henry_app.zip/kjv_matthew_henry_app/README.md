# KJV Study Companion — Android-ready starter app

This is an installable Progressive Web App (PWA) starter intended for Android Chrome. It is not yet a signed APK and is not published in Google Play. Host it over HTTPS, open it in Chrome on Android, then use **⋮ → Add to Home screen** or **Install app**.

## Included in this starter

- Bible reader UI for all 66 canonical books and chapter navigation.
- Verse selection and a commentary panel immediately below the selected verse.
- Local bookmarks using browser storage.
- Search across the chapters loaded in the current session and exact-reference navigation.
- Strong's tagged chapter lookups through jsonBible.org.
- Import panel for a full commentary JSON file and a dictionary JSON file.
- Source links for public-domain text editions.

## Important current limitations

- Bible verses and Strong's-tagged text are requested online from jsonBible.org. This starter does not bundle the entire Bible dataset offline.
- The complete Matthew Henry commentary corpus is **not embedded** in this starter. It must be imported as JSON to display within the app. A source page alone is not the same as having the entire commentary integrated.
- Search currently searches chapters fetched during the current browser session, not an indexed offline copy of all 31,102 verses.
- The Webster 1828 tab currently links to an online dictionary. Import support is provided, but the exact schema of a dictionary export must be adapted if you want inline definitions for every word.
- This starter has not been packaged, signed, or tested as a native Android APK.

## Data rights and recommended sources

- **KJV:** jsonBible.org describes its KJV text and Strong's numbering as public domain and its data format/software as CC0. See https://jsonbible.org/ and https://jsonbible.org/.
- **Matthew Henry:** STEP Bible labels its MHC text “Public Domain--Copy Freely”: https://www.stepbible.org/version.jsp?version=MHC. Scripture.how presents a Matthew Henry Complete Commentary digital edition and labels it public domain / CC0: https://scripture.how/en/commentaries/mhc. Before redistributing a downloaded corpus, verify the specific source file's license, edition, attribution instructions, and whether its download terms permit redistribution. The original historical text is public domain in the United States, but a particular transcription or modern editorial layer can have separate terms.
- **Webster's 1828:** the original 1828 dictionary text is historical, but a particular digital transcription or API may have terms. Confirm the specific data source and rights before bundling it.

## Commentary JSON schema

The importer expects a JSON array (or an object containing an `entries` or `commentary` array). Each entry can use these fields:

```json
[
  {
    "book": "John",
    "chapter": 3,
    "startVerse": 14,
    "endVerse": 21,
    "reference": "John 3:14-21",
    "text": "Full unabridged commentary passage text goes here."
  }
]
```

A commentary paragraph often covers a range of verses, not a unique paragraph per verse. Use `startVerse` and `endVerse` to map the full original passage to every verse it covers. The app displays the entire imported passage when a covered verse is selected. `book` should match one of the 66 English book names shown in the app. Entries with `verse` only are also accepted as one-verse entries.

## Hosting and installation

1. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to any static HTTPS host (for example, GitHub Pages or another static host).
2. Open the HTTPS address in Chrome on Android.
3. Use Chrome's menu → **Install app** or **Add to Home screen**.
4. For full offline Bible and commentary use, add local data files and update the app to index/cache them. Service worker currently caches the app shell only.

## Next production steps

1. Obtain and validate complete 66-book KJV JSON and Strong's lexicon files; add provenance and checksums.
2. Obtain a complete public-domain Matthew Henry corpus, normalize its section headings/ranges, and import it into an indexed local database.
3. Integrate a licensed Webster 1828 dataset and inline definition lookup.
4. Build a full-text local search index and offline data storage (IndexedDB/SQLite).
5. Test verse mapping across all 66 books, accessibility, large-font display, Android installation, and offline behavior.
6. If a native APK is required, wrap the PWA with Capacitor or build a native Android shell, then sign and test the APK/AAB.
